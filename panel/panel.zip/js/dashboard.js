$(document).ready(function() { 
    $('#dropdown').click(function() {
        $(".dropdown-settings").fadeToggle("fast");
    });
});


